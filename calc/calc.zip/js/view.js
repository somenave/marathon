const resetAllBtn = document.querySelector('.calc-reset__all');
const resetSomeBtn = document.querySelector('.calc-reset__some');
const actions = document.querySelector('#actions');
const equalBtn = document.querySelector('#equal');
let result = document.querySelector('.calc-result');
let resultValue = result.textContent;
const numbers = document.querySelectorAll('.calc-numbers__item');

export {resetAllBtn, resetSomeBtn, actions, equalBtn, result, resultValue, numbers};